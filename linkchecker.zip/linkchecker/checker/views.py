from django.shortcuts import render
import validators  
import re

# A basic fake link detection function
def is_suspicious(url):
    # Common signs of fake links
    suspicious_patterns = [
        r"[\w\-\.]+@(?!gmail|yahoo|outlook)",  # Fake email domains
        r"(https?://)?(\d{1,3}\.){3}\d{1,3}",  # IP address instead of domain
        r"(https?://)?[a-zA-Z0-9\-]+\.(xyz|info|top|loan)",  # Suspicious domains
        r"\.com[^/]",  # Missing proper TLD
    ]
    if not validators.url(url):
        return True
    for pattern in suspicious_patterns:
        if re.search(pattern, url):
            return True
    return False

def check_link(request):
    result = None
    url = None
    if request.method == "POST":
        url = request.POST.get("url")
        result = "Suspicious" if is_suspicious(url) else "Trusted"
    return render(request, "checker/check_link.html", {"result": result, "url": url})

